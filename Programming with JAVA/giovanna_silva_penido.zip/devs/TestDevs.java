package devs;

import java.util.Scanner;

public class TestDevs {

    static Desenvolvedor[] desenvolvedores = new Desenvolvedor[2];
    static Funcao[] funcoes = new Funcao[1];
    static Projeto[] projetos = new Projeto[1];

    public static void cadastrarDevs() {
        desenvolvedores[0] = new Desenvolvedor(1, "Gigi", "gigi@mail.com",3000,projetos[0],funcoes[0]);
        desenvolvedores[1] = new Desenvolvedor(2, "Lala", "lala@mail.com",2500,projetos[1],funcoes[1]);
        desenvolvedores[2] = new Desenvolvedor(3, "Amanda", "mands@mail.com",4700,projetos[1],funcoes[1]);
    }

    public static void cadastrarFunc() {
        funcoes[0] = new Funcao("gerente","sênior");
        funcoes[1] = new Funcao("front-end","junior");
    }

    public static void cadastrarProjetos() {
        projetos[0] = new Projeto("Um");
        projetos[1] = new Projeto("Dois");
    }

    public static void cadastrarAA() {
        projetos[0].incluirDesenvolvedor(desenvolvedores[0]);
        projetos[1].incluirDesenvolvedor(desenvolvedores[1]);
        projetos[1].incluirDesenvolvedor(desenvolvedores[2]);
    }

    public static void loadData() {
        cadastrarDevs();
        cadastrarFunc();
        cadastrarProjetos();
        // cadastrarAA();
    }

    public static int menuPrincipal() {
        int op;
        Scanner in = new Scanner(System.in);
        System.out.println("\n============ MENU PRINCIPAL ============");
        System.out.println("01 - Listar Categorias");
        System.out.println("02 - Listar Unidades");
        System.out.println("03 - Listar Veiculos");
        System.out.println("04 - Listar Veiculos por Unidade");
        System.out.println("05 - Transferir veiculos entre Unidades");
        System.out.println("=========================================");
        System.out.print("Digite uma opçao (-1 para sair): ");
        op = in.nextInt();
        return op;
    }

    public static void menuSecundario(int op) {
        Scanner in = new Scanner(System.in);
        switch (op) {
            case 1:
                System.out.println("========== CATEGORIAS =============================");
                for (Desenvolvedor desenvolvedor : desenvolvedores) {
                    System.out.println(desenvolvedor);
                }
                break;
            case 2:
                System.out.println("========== UNIDADES =============================");
                for (Funcao funcao : funcoes) {
                    System.out.println(funcao);
                }
                break;
            case 3:
                System.out.println("========== VEICULOS =============================");
                for (Projeto projeto : projetos) {
                    System.out.println(projeto);
                }
                break;
        }
    }

    public static void main(String[] args) {
        int op = 0;
        loadData();
        while (op >= 0) {
            op = menuPrincipal();
            menuSecundario(op);
        }
    }
}

