package devs;

public class Funcao {
    private String nome;
    private String nivel;

    public Funcao(String nome, String nivel) {
        this.nome = nome;
        this.nivel = nivel;
    }



    @Override
    public String toString() {
        return "Funcao{" +
                "nome='" + nome + '\'' +
                ", nivel='" + nivel + '\'' +
                '}';
    }
}
