package devs;

import java.util.Arrays;

public class Projeto {

    private String nome;
    private int qtDesenvolvedores;
    private int tamMaximoEquipe = 5;
    private Desenvolvedor equipe[];

    public Projeto(String nome) {
        this.nome = nome;
        this.qtDesenvolvedores = 0;
        this.equipe = new Desenvolvedor[tamMaximoEquipe];
    }

    public void incluirDesenvolvedor(Desenvolvedor dev) {
        if (qtDesenvolvedores < tamMaximoEquipe) {
            equipe[qtDesenvolvedores] = dev;
            qtDesenvolvedores++;
            System.out.println("Desenvolvedor inserido com sucesso.");

        }
        System.out.println("A equipe já está completa!");
    }

    public void printEquipe(){
        if(qtDesenvolvedores == 0){
            System.out.println("A equipe não possui nenhum participante.");
        } else {
            for (int i = 0; i < qtDesenvolvedores; i++)
                System.out.println(equipe[i]);
        }
    }

    @Override
    public String toString() {
        return "Projeto{" +
                "nome='" + nome + '\'' +
                ", qtDesenvolvedores=" + qtDesenvolvedores +
                ", tamMaximoEquipe=" + tamMaximoEquipe +
                ", equipe=" + Arrays.toString(equipe) +
                '}';
    }
}
