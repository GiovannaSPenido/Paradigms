package devs;

public class Desenvolvedor {
    private int id;
    private String nome;
    private String email;
    private float salarioBruto;
    private Projeto projeto;
    private Funcao funcao;

    public Desenvolvedor(int id, String nome, String email, float salarioBruto, Projeto projeto, Funcao funcao) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.salarioBruto = salarioBruto;
        this.projeto = projeto;
        this.funcao = funcao;
    }

    private boolean validarQuantidadeFaltas(int faltas){
        if(faltas > 30){
            System.out.println("Erro! O número inserido de faltas é maior que o número de dias que se pode trabalhar no mês");
            return false;
        } else {
            return true;
        }
    }

    public float calcularSalarioBrutoReal(int faltas){
        float salarioBrutoReal;
        salarioBrutoReal = this.salarioBruto - (this.salarioBruto /30) * faltas;
        return salarioBrutoReal;
    }

    public float calcularSalarioLiquido(int faltas){
        double inss = 0.11;
        double irpf;
        if(this.salarioBruto <= 1903.98) {
            irpf = 0;
        } else if(this.salarioBruto >= 1903.99 && this.salarioBruto <= 2826.65) {
            irpf = 0.075;
        } else if(this.salarioBruto >= 2826.66 && this.salarioBruto <= 3751.05) {
            irpf = 0.15;
        } else if(this.salarioBruto >= 3751.06 && this.salarioBruto <= 4664.68) {
            irpf = 0.225;
        } else {
            irpf = 0.275;
        }
        double salarioLiquido;
        double salarioBrutoReal = calcularSalarioBrutoReal(faltas);
        salarioLiquido = salarioBrutoReal - ((this.salarioBruto * inss) + (this.salarioBruto * irpf));
        return (float) salarioLiquido;
    }

    public void setFuncao(Funcao funcao) {
        this.funcao = funcao;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    @Override
    public String toString() {
        return "Desenvolvedor{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", salarioBruto=" + salarioBruto +
                ", projeto=" + projeto +
                ", funcao=" + funcao +
                '}';
    }
}
